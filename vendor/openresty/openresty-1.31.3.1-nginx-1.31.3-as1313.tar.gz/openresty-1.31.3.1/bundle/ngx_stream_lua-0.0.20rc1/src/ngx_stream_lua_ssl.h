
/*
 * !!! DO NOT EDIT DIRECTLY !!!
 * This file was automatically generated from the following template:
 *
 * src/subsys/ngx_subsys_lua_ssl.h.tt2
 */


/*
 * Copyright (C) Yichun Zhang (agentzh)
 */


#ifndef _NGX_STREAM_LUA_SSL_H_INCLUDED_
#define _NGX_STREAM_LUA_SSL_H_INCLUDED_


#include "ngx_stream_lua_common.h"


#if (NGX_STREAM_SSL)


typedef struct {
    ngx_connection_t            *connection; /* original true connection */
    ngx_stream_lua_request_t    *request;    /* fake request */
    ngx_pool_cleanup_pt         *cleanup;

    ngx_ssl_session_t       *session;    /* retrurn value for openssl's
                                          * session_get_cb */

    ngx_str_t                session_id;

#ifdef HAVE_LUA_PROXY_SSL
    X509_STORE_CTX          *x509_store;
    ngx_pool_t              *pool;
#endif

    int                      exit_code;  /* exit code for openssl's
                                            set_client_hello_cb or
                                            set_cert_cb callback or
                                            SSL_CTX_set_cert_verify_callback */

    int                      ctx_ref;    /* reference to anchor
                                            request ctx data in lua
                                            registry */

    unsigned                 done:1;
    unsigned                 aborted:1;

    unsigned                 entered_client_hello_handler:1;
    unsigned                 entered_cert_handler:1;
    unsigned                 entered_sess_fetch_handler:1;
#ifdef HAVE_LUA_PROXY_SSL
    unsigned                 entered_proxy_ssl_cert_handler:1;
    unsigned                 entered_proxy_ssl_verify_handler:1;
#endif
} ngx_stream_lua_ssl_ctx_t;


typedef struct {
    ngx_ssl_t     *ssl;
    ngx_fd_t       fd;
    ngx_str_t      name;
} ngx_stream_lua_ssl_key_log_t;


ngx_int_t ngx_stream_lua_ssl_init(ngx_log_t *log);


extern int ngx_stream_lua_ssl_ctx_index;
extern int ngx_stream_lua_ssl_key_log_index;


#endif


#endif  /* _NGX_STREAM_LUA_SSL_H_INCLUDED_ */
